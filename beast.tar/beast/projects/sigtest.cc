#include "wxsimenv.h"

#include "signal.cc"

BEGIN_SIMULATION_TABLE
	ADD_SIMULATION("Signal", SignalSimulation)
END_SIMULATION_TABLE
